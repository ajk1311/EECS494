#!/bin/bash

xbuild GameServer/GameServer.sln
