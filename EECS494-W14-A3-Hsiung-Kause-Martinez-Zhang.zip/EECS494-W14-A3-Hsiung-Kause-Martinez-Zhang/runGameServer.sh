#!/bin/bash

mono GameServer/ConsoleApplication1/bin/Debug/ConsoleApplication1.exe
