using System;
namespace MyMinimap
{
		public enum SegmentState : byte
		{
			Destroyed = 0,
			Loading = 1,
			Active = 2,
		}
}

