using System;
using System.Collections;

namespace MyMinimap
{
		public interface IMapLoader
		{
				void StartAsyncMethod(IEnumerator method);
		}
}

